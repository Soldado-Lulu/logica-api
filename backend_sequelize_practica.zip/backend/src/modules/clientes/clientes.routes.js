import { Router } from 'express';
import { listarClientes, obtenerCliente, crearCliente, actualizarCliente, borrarCliente } from './clientes.controller.js';

const router = Router();
router.get('/', listarClientes);
router.get('/:id', obtenerCliente);
router.post('/', crearCliente);
router.patch('/:id', actualizarCliente);
router.delete('/:id', borrarCliente);
export default router;
