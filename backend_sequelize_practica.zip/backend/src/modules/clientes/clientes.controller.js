import {
  listarClientesService, obtenerClienteService, crearClienteService,
  actualizarClienteService, eliminarClienteService,
} from './clientes.service.js';

function manejarError(error, res) {
  console.error('Error en clientes:', error);
  if (error.name === 'SequelizeUniqueConstraintError') {
    return res.status(409).json({ ok: false, mensaje: 'El correo ya existe' });
  }
  if (error.name === 'SequelizeValidationError' || error.name === 'SequelizeDatabaseError' && error.parent?.code === '23514') {
    return res.status(400).json({ ok: false, mensaje: 'Datos del cliente invalidos', detalles: error.errors?.map(e => e.message) });
  }
  if (error.name === 'SequelizeForeignKeyConstraintError') {
    return res.status(409).json({ ok: false, mensaje: 'El cliente esta relacionado con otros registros' });
  }
  return res.status(500).json({ ok: false, mensaje: 'Error interno del servidor' });
}

function idValido(id) { return /^[1-9]\d*$/.test(id); }

export async function listarClientes(req, res) {
  try {
    const clientes = await listarClientesService();
    return res.status(200).json({ ok: true, total: clientes.length, data: clientes });
  } catch (error) { return manejarError(error, res); }
}

export async function obtenerCliente(req, res) {
  if (!idValido(req.params.id)) return res.status(400).json({ ok: false, mensaje: 'ID invalido' });
  try {
    const cliente = await obtenerClienteService(req.params.id);
    if (!cliente) return res.status(404).json({ ok: false, mensaje: 'Cliente no encontrado' });
    return res.status(200).json({ ok: true, data: cliente });
  } catch (error) { return manejarError(error, res); }
}

export async function crearCliente(req, res) {
  try {
    const cliente = await crearClienteService(req.body);
    return res.status(201).json({ ok: true, mensaje: 'Cliente creado', data: cliente });
  } catch (error) { return manejarError(error, res); }
}

export async function actualizarCliente(req, res) {
  if (!idValido(req.params.id)) return res.status(400).json({ ok: false, mensaje: 'ID invalido' });
  try {
    const cliente = await actualizarClienteService(req.params.id, req.body);
    if (!cliente) return res.status(404).json({ ok: false, mensaje: 'Cliente no encontrado' });
    return res.status(200).json({ ok: true, data: cliente });
  } catch (error) { return manejarError(error, res); }
}

export async function borrarCliente(req, res) {
  if (!idValido(req.params.id)) return res.status(400).json({ ok: false, mensaje: 'ID invalido' });
  try {
    const afectados = await eliminarClienteService(req.params.id);
    if (!afectados) return res.status(404).json({ ok: false, mensaje: 'Cliente no encontrado' });
    return res.status(200).json({ ok: true, mensaje: 'Cliente eliminado' });
  } catch (error) { return manejarError(error, res); }
}
