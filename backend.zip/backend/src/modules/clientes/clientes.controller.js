import { listarClientesService,obtenerClienteService } from './clientes.service.js';

export async function listarClientes(req, res) {
  try {
    const clientes = await listarClientesService();
    return res.status(200).json({ ok: true, total: clientes.length, data: clientes });
  } catch (error) {
    console.error('Error al listar clientes:', error);
    return res.status(500).json({ ok: false, mensaje: 'Error al listar clientes' });
  }
}

export async function obtenerCliente(req, res) {
  try {
    const clientes = await obtenerClienteService();
    return res.status(200).json({ ok: true, total: clientes.length, data: clientes });
  } catch (error) {
    console.error('Error al obtener cliente:', error);
    return res.status(500).json({ ok: false, mensaje: 'Error al obtener cliente' });
  }
}

export async function crearCliente(req, res) {
  try {
    const clienteCreado = await crearClienteService(nuevoCliente);
    return res.status(201).json({ ok: true, mensaje: 'Cliente creado exitosamente', data: clienteCreado });
  } catch (error) {
    console.error('Error al crear cliente:', error);
    return res.status(500).json({ ok: false, mensaje: 'Error al crear cliente' });
  } 
} 