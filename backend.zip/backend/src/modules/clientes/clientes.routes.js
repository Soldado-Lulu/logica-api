import { Router } from 'express';
import { listarClientes,obtenerCliente } from './clientes.controller.js';

const router = Router();

//router.get('/', listarClientes);
 router.get('/', obtenerCliente);
 router.post('/', crearCliente);
// router.patch('/:id', actualizarCliente);

export default router;
